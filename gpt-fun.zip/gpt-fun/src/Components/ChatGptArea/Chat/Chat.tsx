import { chatGptService } from "../../../Services/ChatGptService";
import "./Chat.css";

export function Chat(): JSX.Element {
    function send(){
        const prompt= "hello";
        chatGptService.getCompletion(prompt)
        .then(completion=>alert(completion))
        .catch(err=>alert(err.message));
    }
    return (
        <div className="Chat">
			<form>
                <label> Job Interview Subject</label>
                <input type="text"/>
                
                <label> number of questions</label>
                <input type="number" min="1" max="20"/>

                <button onClick={send}>Get questions</button>

                
            </form>
        </div>
    );
}
