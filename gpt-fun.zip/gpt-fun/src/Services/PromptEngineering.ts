class PromptEngineering {
	public getPrompt(tech:string, num:number):string{
        const prompt = `please write me ${num} job interview questions in the field of 
        programming technology, and in the sub field of ${tech}`
 
    }
}

export const promptEngineering = new PromptEngineering();
