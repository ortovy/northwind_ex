class AppConfig {
	public chatGptUrl = "https:/api.openai.com/v1/chat/completions";
    public apiKey="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";
}

export const appConfig = new AppConfig();
